<!DOCTYPE html>
<html>
<head>
    <mate charset="utf-8">
        <title>This is about page</title>
        </head>

<body>
<h1>The content of the about page form controller</h1>
<h2><a href="{{ route('contect.page')}}">Contect</a></h2>
</body>

</html>
