<img src="{{ asset('logo/3mro.png') }}" width="100px">
<!-- photo logo for login form  -->
