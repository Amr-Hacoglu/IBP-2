<!DOCTYPE html>
<html>
<head>
    <mate charset="utf-8">
        <title>This is about page</title>
        </head>

<body>
<h1>Contect Page</h1>
<h2><a href="{{ route('about.page')}}">About</a></h2>

<!-- Also we can use it as below
        Route::get('/about','Index');
        <h2><a href="{{ url('/about')}}">About</a></h2> -->

<!-- echo "hi"; -->



</body>

</html>
