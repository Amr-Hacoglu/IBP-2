<?php
$word = "Hi I'm Amr";
echo $word;
?>

{{$word}} //display the data on the blade form

if($word){

}else{

}

@if

@endif

@foreach

@endforeach
